"""Q3: Display the RGB and HSV versions of the same image in separate windows."""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

# OpenCV loads images as BGR; convert to RGB for the RGB version
rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

# Convert to HSV (Hue, Saturation, Value)
hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

# Note: OpenCV's imshow expects BGR, so the RGB array will show with
# red and blue swapped on screen. We convert it back to BGR for display
# only to keep the window colors correct, and the HSV image is shown
# as-is so its (hue-based) appearance is visible.
cv2.imshow("Q3 - RGB Version", cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
cv2.imshow("Q3 - HSV Version", hsv)

cv2.waitKey(0)
cv2.destroyAllWindows()
