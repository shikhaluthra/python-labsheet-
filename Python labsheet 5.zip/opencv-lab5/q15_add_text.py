"""Q15: Add text to an image using different font styles and sizes."""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

# Several built-in OpenCV font faces, each with a different scale (size)
styles = [
    ("SIMPLEX", cv2.FONT_HERSHEY_SIMPLEX),
    ("PLAIN", cv2.FONT_HERSHEY_PLAIN),
    ("DUPLEX", cv2.FONT_HERSHEY_DUPLEX),
    ("COMPLEX", cv2.FONT_HERSHEY_COMPLEX),
    ("TRIPLEX", cv2.FONT_HERSHEY_TRIPLEX),
    ("SCRIPT", cv2.FONT_HERSHEY_SCRIPT_SIMPLEX),
]
sizes = [0.8, 1.2, 1.6]   # small, medium, large

output = image.copy()
y = 40
for name, font in styles:
    # Each style gets its own line; the size cycles through the list
    scale = sizes[styles.index((name, font)) % len(sizes)]
    cv2.putText(output, f"{name} {scale}", (10, y), font, scale,
                (0, 255, 255), 2, cv2.LINE_AA)
    y += int(40 * scale) + 20

cv2.imshow("Q15 - Text Styles and Sizes", output)
cv2.waitKey(0)
cv2.destroyAllWindows()
