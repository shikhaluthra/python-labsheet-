"""Q11: Capture video from a webcam and display it live. Press 'q' to quit."""
import cv2

# Open the default camera (index 0)
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise SystemExit("Error: could not open webcam")

while True:
    ok, frame = cap.read()        # Grab one frame
    if not ok:
        break

    cv2.imshow("Q11 - Live Webcam", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

# Release the camera and close windows
cap.release()
cv2.destroyAllWindows()
