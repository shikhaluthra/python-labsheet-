"""Q6: Flip an image horizontally, vertically, and both ways."""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

# flipCode: 1 = horizontal (around y-axis), 0 = vertical (around x-axis),
#           -1 = both
horizontal = cv2.flip(image, 1)
vertical = cv2.flip(image, 0)
both = cv2.flip(image, -1)

cv2.imshow("Q6 - Original", image)
cv2.imshow("Q6 - Horizontal Flip", horizontal)
cv2.imshow("Q6 - Vertical Flip", vertical)
cv2.imshow("Q6 - Both Flips", both)
cv2.waitKey(0)
cv2.destroyAllWindows()
