"""Q10: Identify and classify circles, rectangles and triangles in an image.

Method:
  1. Convert to grayscale and threshold to get a binary image.
  2. Find contours (outlines) of each object.
  3. Approximate each contour with fewer points (approxPolyDP).
  4. Classify by vertex count, and use circularity to detect circles.
"""
import sys
import math
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/shapes.png"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
gray = cv2.GaussianBlur(gray, (5, 5), 0)

# Otsu's method picks the threshold automatically; INV makes shapes white
_, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

for cnt in contours:
    area = cv2.contourArea(cnt)
    if area < 500:                       # ignore small noise
        continue

    perimeter = cv2.arcLength(cnt, True)
    approx = cv2.approxPolyDP(cnt, 0.04 * perimeter, True)
    vertices = len(approx)

    # Circularity is 1.0 for a perfect circle, lower for other shapes
    circularity = 4 * math.pi * area / (perimeter * perimeter)

    if vertices == 3:
        shape = "Triangle"
    elif vertices == 4:
        shape = "Rectangle"
    elif circularity > 0.8:
        shape = "Circle"
    else:
        shape = "Other"

    # Mark the object and label it at its top-left corner
    x, y, w, h = cv2.boundingRect(approx)
    cv2.drawContours(image, [approx], -1, (0, 255, 0), 2)
    cv2.putText(image, shape, (x, y - 8), cv2.FONT_HERSHEY_SIMPLEX,
                0.6, (0, 0, 255), 2)
    print(f"{shape}: vertices={vertices}, circularity={circularity:.2f}")

cv2.imshow("Q10 - Shape Classification", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
