"""Q2: Convert a color image to grayscale and show both side by side."""
import sys
import cv2
import numpy as np

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

# Convert BGR (OpenCV's default order) to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Grayscale is single-channel; convert back to 3 channels so it can be
# stacked horizontally with the color image
gray_bgr = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

# Place the two images side by side
combined = np.hstack((image, gray_bgr))

cv2.imshow("Q2 - Color (left) vs Grayscale (right)", combined)
cv2.waitKey(0)
cv2.destroyAllWindows()
