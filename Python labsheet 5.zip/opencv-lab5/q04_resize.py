"""Q4: Resize an image to 200x200 pixels."""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

# cv2.resize takes (width, height). This forces the exact size and
# does not preserve the aspect ratio.
resized = cv2.resize(image, (200, 200), interpolation=cv2.INTER_AREA)

print(f"Original size: {image.shape[1]}x{image.shape[0]}")
print(f"Resized size:  {resized.shape[1]}x{resized.shape[0]}")

cv2.imshow("Q4 - Original", image)
cv2.imshow("Q4 - Resized 200x200", resized)
cv2.waitKey(0)
cv2.destroyAllWindows()
