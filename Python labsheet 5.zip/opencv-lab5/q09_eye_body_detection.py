"""Q9: Detect eyes or a full body using pre-trained Haar cascade models.

Usage:
    python q09_eye_body_detection.py images/sample.jpg eyes
    python q09_eye_body_detection.py images/people.jpg body
"""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
mode = sys.argv[2].lower() if len(sys.argv) > 2 else "eyes"

image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Choose the pre-trained model based on the requested mode
models = {
    "eyes": ("haarcascade_eye.xml", (255, 0, 0)),              # blue boxes
    "body": ("haarcascade_fullbody.xml", (0, 0, 255)),         # red boxes
}
if mode not in models:
    sys.exit("Mode must be 'eyes' or 'body'")

model_file, color = models[mode]
cascade = cv2.CascadeClassifier(cv2.data.haarcascades + model_file)

detections = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
print(f"{mode.capitalize()} detected: {len(detections)}")

for (x, y, w, h) in detections:
    cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)

cv2.imshow(f"Q9 - {mode.capitalize()} Detection", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
