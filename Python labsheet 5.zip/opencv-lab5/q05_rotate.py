"""Q5: Rotate an image by a given angle (default 45 degrees)."""
import sys
import cv2
import numpy as np

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
angle = float(sys.argv[2]) if len(sys.argv) > 2 else 45.0

image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

h, w = image.shape[:2]
center = (w / 2, h / 2)

# Rotation matrix around the image center (positive angle = counter-clockwise)
matrix = cv2.getRotationMatrix2D(center, angle, 1.0)

# Compute the size of the new canvas so the rotated image is not cropped
cos, sin = abs(matrix[0, 0]), abs(matrix[0, 1])
new_w = int(h * sin + w * cos)
new_h = int(h * cos + w * sin)

# Shift the matrix so the rotated image is centered on the bigger canvas
matrix[0, 2] += new_w / 2 - center[0]
matrix[1, 2] += new_h / 2 - center[1]

rotated = cv2.warpAffine(image, matrix, (new_w, new_h))

cv2.imshow(f"Q5 - Rotated by {angle} degrees", rotated)
cv2.waitKey(0)
cv2.destroyAllWindows()
