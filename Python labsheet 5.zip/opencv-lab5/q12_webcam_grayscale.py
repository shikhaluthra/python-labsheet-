"""Q12: Convert each webcam frame to grayscale in real time. Press 'q' to quit."""
import cv2

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise SystemExit("Error: could not open webcam")

while True:
    ok, frame = cap.read()
    if not ok:
        break

    # Process each frame individually
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    cv2.imshow("Q12 - Grayscale Webcam", gray)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
