"""Q7: Crop a specific region from an image and display it."""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

h, w = image.shape[:2]

# Region of interest: the central half of the image.
# Format: rows (y) start:end, columns (x) start:end
y1, y2 = h // 4, 3 * h // 4
x1, x2 = w // 4, 3 * w // 4

# NumPy slicing crops the image without copying the whole array
cropped = image[y1:y2, x1:x2]

print(f"Cropped region: x={x1}-{x2}, y={y1}-{y2}")

# Show the original with the crop rectangle, and the cropped result
marked = image.copy()
cv2.rectangle(marked, (x1, y1), (x2, y2), (0, 255, 0), 2)

cv2.imshow("Q7 - Region Selected", marked)
cv2.imshow("Q7 - Cropped Region", cropped)
cv2.waitKey(0)
cv2.destroyAllWindows()
