"""Q13: Capture and save 100 frames from a live webcam feed as image files.

Frames are saved to the 'captured_frames/' folder as JPEG files.
"""
import os
import cv2

OUTPUT_DIR = "captured_frames"
TOTAL_FRAMES = 100

os.makedirs(OUTPUT_DIR, exist_ok=True)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise SystemExit("Error: could not open webcam")

saved = 0
while saved < TOTAL_FRAMES:
    ok, frame = cap.read()
    if not ok:
        print("Warning: failed to read frame, retrying...")
        continue

    # Show the feed so the user can see what is being captured
    cv2.imshow("Q13 - Capturing", frame)

    filename = os.path.join(OUTPUT_DIR, f"frame_{saved + 1:03d}.jpg")
    cv2.imwrite(filename, frame)
    saved += 1
    print(f"Saved {filename} ({saved}/{TOTAL_FRAMES})")

    # Allow the window to refresh; press 'q' to stop early
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print(f"Done. Saved {saved} frames to '{OUTPUT_DIR}/'")
