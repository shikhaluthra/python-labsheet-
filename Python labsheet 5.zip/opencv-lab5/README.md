# Lab Sheet-5: Python Libraries and Applications (OpenCV)

Solutions for the 15 OpenCV problems in COER University Lab Sheet-5.
Each problem is implemented as a separate, standalone Python program.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

Put test images in the `images/` folder (for example `images/sample.jpg`).
Most programs accept an image path as an argument and fall back to `images/sample.jpg`:

```bash
python q01_load_display.py images/sample.jpg
```

Webcam programs (Q11, Q12, Q13) use the default camera (index 0). Press `q` to quit.

## Programs

| File | Problem |
|------|---------|
| `q01_load_display.py` | Load and display an image |
| `q02_grayscale_side_by_side.py` | Color to grayscale, side-by-side display |
| `q03_rgb_hsv_windows.py` | RGB and HSV versions in separate windows |
| `q04_resize.py` | Resize to 200x200 |
| `q05_rotate.py` | Rotate by a given angle (default 45°) |
| `q06_flip.py` | Horizontal, vertical and both flips |
| `q07_crop.py` | Crop a region and display it |
| `q08_face_detection.py` | Haar cascade face detection |
| `q09_eye_body_detection.py` | Eye and full-body detection with Haar cascades |
| `q10_shape_classification.py` | Classify circle, rectangle, triangle |
| `q11_webcam_live.py` | Live webcam display |
| `q12_webcam_grayscale.py` | Real-time grayscale webcam feed |
| `q13_capture_frames.py` | Save 100 webcam frames |
| `q14_draw_shapes.py` | Draw rectangle, circle and line on a blank canvas |
| `q15_add_text.py` | Text with different fonts and sizes |

## Output

Programs that write files save them to `outputs/` (created automatically).
Q13 saves frames to `captured_frames/`.
