"""Q8: Detect faces with Haar cascades and draw rectangles around them."""
import sys
import cv2

path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

# Haar cascade classifiers work on grayscale images
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Load the pre-trained frontal face model shipped with OpenCV
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# scaleFactor: how much the image shrinks at each scale step
# minNeighbors: higher = fewer but more reliable detections
faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5,
                                      minSize=(30, 30))
print(f"Faces detected: {len(faces)}")

# Draw a green rectangle around each face
for (x, y, w, h) in faces:
    cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)

cv2.imshow("Q8 - Face Detection", image)
cv2.waitKey(0)
cv2.destroyAllWindows()
