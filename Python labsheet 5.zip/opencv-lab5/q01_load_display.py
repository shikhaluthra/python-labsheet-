"""Q1: Load and display an image using OpenCV."""
import sys
import cv2

# Use the path given on the command line, or a default sample image
path = sys.argv[1] if len(sys.argv) > 1 else "images/sample.jpg"

# Read the image from disk (returns None if the file cannot be read)
image = cv2.imread(path)
if image is None:
    sys.exit(f"Error: could not load image '{path}'")

print(f"Loaded '{path}' with shape {image.shape} (height, width, channels)")

cv2.imshow("Q1 - Original Image", image)
cv2.waitKey(0)              # Wait until a key is pressed
cv2.destroyAllWindows()
