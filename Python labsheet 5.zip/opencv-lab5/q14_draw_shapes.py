"""Q14: Draw a rectangle, a circle and a line on a blank canvas."""
import numpy as np
import cv2

# Create a black 500x500 canvas with 3 color channels (BGR)
canvas = np.zeros((500, 500, 3), dtype=np.uint8)

# Rectangle: top-left corner and bottom-right corner, green, thickness 3
cv2.rectangle(canvas, (50, 50), (200, 150), (0, 255, 0), 3)

# Circle: center, radius, red, filled (thickness -1)
cv2.circle(canvas, (350, 100), 60, (0, 0, 255), -1)

# Line: start point, end point, blue, thickness 5
cv2.line(canvas, (50, 400), (450, 300), (255, 0, 0), 5)

cv2.imshow("Q14 - Shapes on Canvas", canvas)
cv2.waitKey(0)
cv2.destroyAllWindows()
