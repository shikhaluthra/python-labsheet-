"""
Q6: Implement an activation function (ReLU) using TensorFlow.
ReLU(x) = max(0, x)
"""
import numpy as np
import tensorflow as tf


def relu_custom(x):
    """Our own ReLU implementation using tf.maximum."""
    x = tf.convert_to_tensor(x, dtype=tf.float32)
    return tf.maximum(tf.constant(0.0, dtype=tf.float32), x)


def relu_derivative(x):
    """Derivative of ReLU: 1 for x > 0, else 0 (used in backpropagation)."""
    x = tf.convert_to_tensor(x, dtype=tf.float32)
    return tf.cast(x > 0, tf.float32)


# Test with a range of values
inputs = tf.constant([-3.0, -1.0, 0.0, 0.5, 2.0, 7.5])
print("Input         :", inputs.numpy())
print("Custom ReLU   :", relu_custom(inputs).numpy())
print("tf.nn.relu    :", tf.nn.relu(inputs).numpy())
print("Derivative    :", relu_derivative(inputs).numpy())

# Verify our implementation matches the built-in one on random data
random_data = np.random.randn(1000).astype("float32")
match = np.allclose(relu_custom(random_data).numpy(), np.maximum(0, random_data))
print("Matches NumPy on 1000 random values:", match)

# Use the custom activation inside a layer
layer_input = tf.constant([[1.0, -2.0, 3.0]])
dense = tf.keras.layers.Dense(4)
out = relu_custom(dense(layer_input))
print("Output of Dense + custom ReLU:", out.numpy())
