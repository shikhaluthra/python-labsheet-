"""
Q7: Create and train a neural network to approximate the sine function.
A small MLP learns y = sin(x) over the interval [-2*pi, 2*pi].
"""
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

np.random.seed(1)
tf.random.set_seed(1)

# 1. Generate training data
X = np.random.uniform(-2 * np.pi, 2 * np.pi, size=(3000, 1)).astype("float32")
y = np.sin(X).astype("float32")

# 2. Build the network (tanh hidden layers are smooth, suited to sine)
model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation="tanh", input_shape=(1,)),
    tf.keras.layers.Dense(64, activation="tanh"),
    tf.keras.layers.Dense(1)
])

# 3. Compile and train
model.compile(optimizer=tf.keras.optimizers.Adam(0.005), loss="mse", metrics=["mae"])
model.fit(X, y, epochs=200, batch_size=64, validation_split=0.1, verbose=0)

# 4. Evaluate on new points not seen in training
X_test = np.linspace(-2 * np.pi, 2 * np.pi, 500).reshape(-1, 1).astype("float32")
y_true = np.sin(X_test)
y_pred = model.predict(X_test, verbose=0)
print("Test MSE:", np.mean((y_true - y_pred) ** 2))

# Sample predictions
for x_val in [0.0, np.pi / 2, np.pi, -np.pi / 2]:
    p = model.predict(np.array([[x_val]], dtype="float32"), verbose=0)[0][0]
    print(f"sin({x_val:.3f}) = {np.sin(x_val):+.4f}, predicted = {p:+.4f}")

# 5. Plot true vs predicted curve
plt.plot(X_test, y_true, label="sin(x)")
plt.plot(X_test, y_pred, "--", label="Network")
plt.legend()
plt.title("Neural Network Approximation of sin(x)")
plt.savefig("q07_sine_approximation.png")
print("Plot saved to q07_sine_approximation.png")
