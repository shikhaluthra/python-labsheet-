"""
Q1: Install and verify the TensorFlow version in your environment.
Manual install (optional): pip install tensorflow
"""
import subprocess
import sys


def install_tensorflow():
    """Install TensorFlow with pip using the current Python interpreter."""
    print("Installing TensorFlow...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--quiet", "tensorflow"])


def verify_tensorflow():
    """Import TensorFlow and print its version and available devices."""
    import tensorflow as tf

    print("TensorFlow version :", tf.__version__)
    print("Keras version      :", tf.keras.__version__)
    gpus = tf.config.list_physical_devices("GPU")
    print("GPU devices        :", gpus if gpus else "None (running on CPU)")


if __name__ == "__main__":
    try:
        import tensorflow  # noqa: F401  (check if it is already installed)
    except ImportError:
        install_tensorflow()
    verify_tensorflow()
