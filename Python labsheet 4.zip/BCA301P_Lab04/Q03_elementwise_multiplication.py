"""
Q3: Use TensorFlow to perform element-wise matrix multiplication.
Element-wise (Hadamard) product: C[i,j] = A[i,j] * B[i,j]
Note: this is different from matrix multiplication (tf.matmul).
"""
import tensorflow as tf

A = tf.constant([[1, 2, 3],
                 [4, 5, 6]], dtype=tf.float32)
B = tf.constant([[7, 8, 9],
                 [1, 2, 3]], dtype=tf.float32)

# Element-wise multiplication (both forms are equivalent)
C1 = tf.multiply(A, B)
C2 = A * B

print("A:\n", A.numpy())
print("B:\n", B.numpy())
print("Element-wise product A * B:\n", C1.numpy())
print("Same result with operator *:", bool(tf.reduce_all(C1 == C2)))

# Compare with true matrix multiplication (needs compatible shapes)
M = tf.matmul(A, tf.transpose(B))
print("Matrix multiplication A @ B^T:\n", M.numpy())

# Test with different inputs
D = tf.constant([[2.0, 0.5], [1.5, -1.0]])
E = tf.constant([[3.0, 4.0], [-2.0, 0.0]])
print("Another test:\n", tf.multiply(D, E).numpy())
