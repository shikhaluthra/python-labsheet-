"""
Q9: Visualize model architecture using model.summary() and plot_model().
plot_model needs Graphviz installed on the system (and pydot via pip).
"""
import tensorflow as tf

model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(10,)),
    tf.keras.layers.Dense(32, activation="relu", name="hidden_1"),
    tf.keras.layers.Dropout(0.2, name="dropout"),
    tf.keras.layers.Dense(16, activation="relu", name="hidden_2"),
    tf.keras.layers.Dense(1, activation="sigmoid", name="output")
], name="demo_model")

# 1. Text summary: layers, output shapes and parameter counts
print("=== model.summary() ===")
model.summary()

total = model.count_params()
print("Total parameters:", total)

# 2. Graphical diagram saved to a PNG file
try:
    tf.keras.utils.plot_model(
        model,
        to_file="q09_model_architecture.png",
        show_shapes=True,
        show_layer_names=True
    )
    print("Architecture diagram saved to q09_model_architecture.png")
except (ImportError, OSError) as err:
    print("plot_model skipped. Install pydot and Graphviz to enable it.")
    print("Reason:", err)
