"""
Q5: Build a custom loss function and use it in model compilation.
Custom loss: Huber-style loss that also penalizes under-prediction
more heavily (useful when missing a value is costly).
"""
import numpy as np
import tensorflow as tf


def custom_asymmetric_huber(y_true, y_pred, delta=1.0, under_weight=2.0):
    """
    Huber loss with an extra penalty when y_pred < y_true.
    Args:
        y_true, y_pred : tensors of the same shape
        delta          : switch point between quadratic and linear regions
        under_weight   : multiplier applied to under-prediction errors
    """
    error = y_true - y_pred
    abs_error = tf.abs(error)

    # Standard Huber: quadratic for small errors, linear for large
    quadratic = 0.5 * tf.square(error)
    linear = delta * (abs_error - 0.5 * delta)
    huber = tf.where(abs_error <= delta, quadratic, linear)

    # Extra weight where the model under-predicts (error > 0)
    weights = tf.where(error > 0, under_weight, 1.0)
    return tf.reduce_mean(weights * huber)


# Synthetic data: y = 2x + noise with a few outliers
np.random.seed(0)
X = np.random.uniform(-3, 3, size=(500, 1)).astype("float32")
y = 2 * X + np.random.normal(0, 0.3, size=(500, 1)).astype("float32")
y[::50] += 8  # add outliers

model = tf.keras.Sequential([
    tf.keras.layers.Dense(16, activation="relu", input_shape=(1,)),
    tf.keras.layers.Dense(1)
])

# Use the custom loss in compile (a lambda passes extra arguments)
model.compile(
    optimizer="adam",
    loss=lambda yt, yp: custom_asymmetric_huber(yt, yp, delta=1.0, under_weight=2.0)
)
model.fit(X, y, epochs=60, batch_size=32, verbose=0)

# Test with different inputs
test_x = np.array([[-2.0], [0.0], [2.5]], dtype="float32")
print("Predictions for", test_x.ravel(), "->", model.predict(test_x, verbose=0).ravel())
print("Expected approx :", (2 * test_x).ravel())

# Check the loss function directly on known values
t = tf.constant([[1.0], [2.0]])
p = tf.constant([[0.0], [3.0]])
print("Custom loss on sample values:", custom_asymmetric_huber(t, p).numpy())
