"""
Q15: Plot and analyze the training and validation loss and accuracy curves.
The History object returned by model.fit() is used to draw both curves
and to give a simple analysis of overfitting or underfitting.
"""
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

np.random.seed(21)
tf.random.set_seed(21)

# Dataset with a moderate amount of noise
X = np.random.randn(1000, 10).astype("float32")
y = (X[:, 0] - X[:, 1] + 0.5 * np.random.randn(1000) > 0).astype("float32")

model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation="relu", input_shape=(10,)),
    tf.keras.layers.Dense(64, activation="relu"),
    tf.keras.layers.Dense(1, activation="sigmoid")
])
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

history = model.fit(X, y, validation_split=0.2, epochs=40, batch_size=32, verbose=0)
h = history.history

# Plot loss and accuracy side by side
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))

ax1.plot(h["loss"], label="Training loss")
ax1.plot(h["val_loss"], label="Validation loss")
ax1.set_title("Loss per epoch")
ax1.set_xlabel("Epoch"); ax1.set_ylabel("Loss"); ax1.legend(); ax1.grid(alpha=0.3)

ax2.plot(h["accuracy"], label="Training accuracy")
ax2.plot(h["val_accuracy"], label="Validation accuracy")
ax2.set_title("Accuracy per epoch")
ax2.set_xlabel("Epoch"); ax2.set_ylabel("Accuracy"); ax2.legend(); ax2.grid(alpha=0.3)

plt.tight_layout()
plt.savefig("q15_loss_accuracy_curves.png")
print("Curves saved to q15_loss_accuracy_curves.png")

# Simple analysis
best_epoch = int(np.argmin(h["val_loss"])) + 1
final_gap = h["accuracy"][-1] - h["val_accuracy"][-1]
print(f"\nBest validation loss at epoch {best_epoch}: {min(h['val_loss']):.4f}")
print(f"Final train accuracy: {h['accuracy'][-1]:.4f}, validation accuracy: {h['val_accuracy'][-1]:.4f}")
if final_gap > 0.05:
    print("Analysis: training accuracy is noticeably higher than validation -> possible overfitting.")
elif h["val_loss"][-1] > min(h["val_loss"]) + 0.05:
    print("Analysis: validation loss rose after its minimum -> overfitting after epoch", best_epoch)
else:
    print("Analysis: training and validation curves are close -> good generalization.")
