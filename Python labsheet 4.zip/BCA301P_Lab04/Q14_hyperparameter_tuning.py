"""
Q14: Perform hyperparameter tuning using Keras Tuner or GridSearchCV with a wrapper.
This program uses GridSearchCV (scikit-learn) with the scikeras wrapper
to search over hidden units, dropout rate and learning rate.
Install: pip install scikeras scikit-learn
(Keras Tuner alternative: pip install keras-tuner)
"""
import numpy as np
import tensorflow as tf
from sklearn.model_selection import GridSearchCV
from scikeras.wrappers import KerasClassifier

np.random.seed(0)
tf.random.set_seed(0)

X = np.random.randn(600, 8).astype("float32")
y = (X[:, 0] * X[:, 1] + X[:, 2] > 0).astype("int32")


def create_model(hidden_units=16, dropout=0.0, learning_rate=0.001):
    """Model builder. Its arguments are tuned through the wrapper."""
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(8,)),
        tf.keras.layers.Dense(hidden_units, activation="relu"),
        tf.keras.layers.Dropout(dropout),
        tf.keras.layers.Dense(1, activation="sigmoid")
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )
    return model


# Wrap the Keras model so scikit-learn can use it
clf = KerasClassifier(model=create_model, epochs=20, batch_size=32, verbose=0)

# Hyperparameter grid (prefix "model__" passes values to create_model)
param_grid = {
    "model__hidden_units": [8, 32],
    "model__dropout": [0.0, 0.3],
    "model__learning_rate": [0.01, 0.001],
}

search = GridSearchCV(estimator=clf, param_grid=param_grid, cv=3, scoring="accuracy", verbose=0)
search.fit(X, y)

print("Best parameters :", search.best_params_)
print(f"Best CV accuracy: {search.best_score_:.4f}")

# Test the best model on new inputs
best_model = search.best_estimator_
test = np.random.randn(5, 8).astype("float32")
print("Predicted classes on new data:", best_model.predict(test))
