"""
Q10: Write code to save and load a trained Keras model.
Saves in the native .keras format (also supports SavedModel and .h5).
"""
import os
import numpy as np
import tensorflow as tf

np.random.seed(0)
tf.random.set_seed(0)

# 1. Train a small model
X = np.random.rand(500, 4).astype("float32")
y = (X.sum(axis=1) > 2).astype("float32")

model = tf.keras.Sequential([
    tf.keras.layers.Dense(8, activation="relu", input_shape=(4,)),
    tf.keras.layers.Dense(1, activation="sigmoid")
])
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
model.fit(X, y, epochs=20, verbose=0)

# 2. Save the complete model (architecture + weights + optimizer state)
path = "saved_model.keras"
model.save(path)
print("Model saved to", path, "| file size:", os.path.getsize(path), "bytes")

# 3. Load it back in a fresh object
loaded = tf.keras.models.load_model(path)
print("Model loaded successfully.")

# 4. Verify that predictions are identical
test = np.random.rand(5, 4).astype("float32")
orig_pred = model.predict(test, verbose=0)
new_pred = loaded.predict(test, verbose=0)
print("Predictions identical:", np.allclose(orig_pred, new_pred))

# 5. Save only the weights (useful when the architecture is defined in code)
model.save_weights("model_weights.weights.h5")
fresh = tf.keras.Sequential([
    tf.keras.layers.Dense(8, activation="relu", input_shape=(4,)),
    tf.keras.layers.Dense(1, activation="sigmoid")
])
fresh.load_weights("model_weights.weights.h5")
print("Weights-only restore matches:", np.allclose(model.predict(test, verbose=0),
                                                  fresh.predict(test, verbose=0)))
