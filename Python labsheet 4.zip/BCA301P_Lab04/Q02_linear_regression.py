"""
Q2: Create a simple linear regression model using TensorFlow.
Model: y = w*x + b, learned by gradient descent on synthetic data.
"""
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

np.random.seed(42)
tf.random.set_seed(42)

# 1. Generate synthetic data: true relation y = 3x + 5 plus noise
X = np.random.uniform(-10, 10, size=(200, 1)).astype("float32")
y = 3 * X + 5 + np.random.normal(0, 1.5, size=(200, 1)).astype("float32")

# 2. Build a model with one Dense unit (a single linear neuron)
model = tf.keras.Sequential([
    tf.keras.layers.Dense(1, input_shape=(1,))
])

# 3. Compile with SGD optimizer and mean squared error loss
model.compile(optimizer=tf.keras.optimizers.SGD(learning_rate=0.01), loss="mse")

# 4. Train
history = model.fit(X, y, epochs=100, batch_size=16, verbose=0)
print("Final training MSE:", round(history.history["loss"][-1], 4))

# 5. Inspect learned parameters (weight w and bias b)
w, b = model.layers[0].get_weights()
print(f"Learned w = {w[0][0]:.3f} (true 3.0), b = {b[0]:.3f} (true 5.0)")

# 6. Predict on new inputs
test_x = np.array([[0.0], [5.0], [-4.0]], dtype="float32")
print("Predictions:", model.predict(test_x, verbose=0).ravel())

# 7. Plot data and fitted line
plt.scatter(X, y, s=10, alpha=0.5, label="Data")
xs = np.linspace(-10, 10, 100).reshape(-1, 1)
plt.plot(xs, model.predict(xs, verbose=0), color="red", label="Fitted line")
plt.legend()
plt.title("Linear Regression with TensorFlow")
plt.savefig("q02_linear_regression.png")
print("Plot saved to q02_linear_regression.png")
