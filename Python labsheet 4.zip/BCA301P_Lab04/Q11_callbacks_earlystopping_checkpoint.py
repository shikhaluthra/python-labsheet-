"""
Q11: Use callbacks like EarlyStopping and ModelCheckpoint during training.
EarlyStopping: stops training when validation loss stops improving.
ModelCheckpoint: saves the best model seen so far.
"""
import numpy as np
import tensorflow as tf

np.random.seed(3)
tf.random.set_seed(3)

# Synthetic binary classification data
X = np.random.randn(1500, 10).astype("float32")
y = (X[:, :3].sum(axis=1) > 0).astype("float32")

model = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation="relu", input_shape=(10,)),
    tf.keras.layers.Dense(64, activation="relu"),
    tf.keras.layers.Dense(1, activation="sigmoid")
])
model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

callbacks = [
    # Stop if val_loss does not improve for 5 epochs; roll back to best weights
    tf.keras.callbacks.EarlyStopping(
        monitor="val_loss", patience=5, restore_best_weights=True, verbose=1
    ),
    # Save only the best model (lowest val_loss) to disk
    tf.keras.callbacks.ModelCheckpoint(
        filepath="best_model.keras", monitor="val_loss",
        save_best_only=True, verbose=1
    )
]

history = model.fit(
    X, y,
    validation_split=0.2,
    epochs=200,            # upper limit; EarlyStopping may end sooner
    batch_size=32,
    callbacks=callbacks,
    verbose=0
)

stopped_at = len(history.history["loss"])
print(f"Training ran for {stopped_at} epochs (max was 200).")
print("Best val_loss:", min(history.history["val_loss"]))

# Load the checkpoint saved by ModelCheckpoint and test it
best = tf.keras.models.load_model("best_model.keras")
print("Checkpoint evaluation:", best.evaluate(X[:300], y[:300], verbose=0))
