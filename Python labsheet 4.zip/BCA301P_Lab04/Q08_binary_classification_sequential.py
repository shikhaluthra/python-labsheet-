"""
Q8: Build a feedforward neural network for binary classification
using the Keras Sequential API.
Synthetic task: label is 1 if x1^2 + x2^2 > 1 (a circular boundary).
"""
import numpy as np
import tensorflow as tf

np.random.seed(7)
tf.random.set_seed(7)

# 1. Create dataset
X = np.random.uniform(-2, 2, size=(2000, 2)).astype("float32")
y = ((X[:, 0] ** 2 + X[:, 1] ** 2) > 1).astype("float32")

# 2. Train / test split (80/20)
split = int(0.8 * len(X))
X_train, X_test = X[:split], X[split:]
y_train, y_test = y[:split], y[split:]

# 3. Build a feedforward network with Sequential API
model = tf.keras.Sequential([
    tf.keras.layers.Dense(16, activation="relu", input_shape=(2,)),
    tf.keras.layers.Dense(16, activation="relu"),
    tf.keras.layers.Dense(1, activation="sigmoid")   # probability of class 1
])

# 4. Compile for binary classification
model.compile(
    optimizer="adam",
    loss="binary_crossentropy",
    metrics=["accuracy"]
)

# 5. Train
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_split=0.1, verbose=0)

# 6. Evaluate
loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test loss: {loss:.4f}, Test accuracy: {acc:.4f}")

# 7. Predict on new inputs (threshold probability at 0.5)
samples = np.array([[0.0, 0.0], [1.5, 1.5], [0.5, 0.2], [-1.8, 0.3]], dtype="float32")
probs = model.predict(samples, verbose=0).ravel()
for s, p in zip(samples, probs):
    label = int(p >= 0.5)
    print(f"Input {s} -> probability {p:.3f} -> class {label}")
