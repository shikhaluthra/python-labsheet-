# BCA301P Lab Sheet-04: Python Libraries and Application

Each question is implemented in its own program.

| File | Question |
|------|----------|
| Q01_install_verify_tensorflow.py | Install and verify TensorFlow |
| Q02_linear_regression.py | Linear regression with TensorFlow |
| Q03_elementwise_multiplication.py | Element-wise matrix multiplication |
| Q04_gradient_tape.py | Gradients with tf.GradientTape |
| Q05_custom_loss_function.py | Custom loss used in compile |
| Q06_relu_activation.py | ReLU implemented with TensorFlow |
| Q07_sine_approximation.py | Neural network approximating sin(x) |
| Q08_binary_classification_sequential.py | Binary classifier, Sequential API |
| Q09_model_architecture_visualization.py | model.summary() and plot_model() |
| Q10_save_load_keras_model.py | Save and load a Keras model |
| Q11_callbacks_earlystopping_checkpoint.py | EarlyStopping and ModelCheckpoint |
| Q12_dropout_overfitting.py | Dropout and overfitting |
| Q13_functional_api_multi_io.py | Functional API, multiple inputs/outputs |
| Q14_hyperparameter_tuning.py | GridSearchCV with scikeras wrapper |
| Q15_plot_loss_accuracy_curves.py | Loss and accuracy curves |

## Setup
    pip install tensorflow matplotlib numpy scikit-learn scikeras pydot

plot_model (Q9) also needs Graphviz installed on the system; otherwise the program skips the diagram and still prints the summary.

## Run
    python Q01_install_verify_tensorflow.py

Generated plots (.png) and saved models are written to the current folder.
