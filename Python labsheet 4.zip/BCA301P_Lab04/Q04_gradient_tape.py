"""
Q4: Demonstrate how to use tf.GradientTape to compute gradients.
GradientTape records operations on variables so that gradients
can be computed automatically (automatic differentiation).
"""
import tensorflow as tf

# Example 1: scalar function y = x^2 + 2x + 1, so dy/dx = 2x + 2
x = tf.Variable(3.0)
with tf.GradientTape() as tape:
    y = x ** 2 + 2 * x + 1
dy_dx = tape.gradient(y, x)
print("Example 1: y = x^2 + 2x + 1 at x = 3")
print("  y      =", y.numpy())
print("  dy/dx  =", dy_dx.numpy(), "(expected 8.0)")

# Example 2: second-order derivative using nested tapes
with tf.GradientTape() as outer:
    with tf.GradientTape() as inner:
        y2 = x ** 3
    dy = inner.gradient(y2, x)        # 3x^2
d2y = outer.gradient(dy, x)           # 6x
print("\nExample 2: y = x^3 at x = 3")
print("  dy/dx   =", dy.numpy(), "(expected 27.0)")
print("  d2y/dx2 =", d2y.numpy(), "(expected 18.0)")

# Example 3: gradients of a loss with respect to a weight vector
w = tf.Variable([1.0, -2.0])
inputs = tf.constant([[1.0, 2.0], [3.0, 4.0]])
targets = tf.constant([1.0, 0.0])
with tf.GradientTape() as tape:
    preds = tf.reduce_sum(inputs * w, axis=1)       # simple linear model
    loss = tf.reduce_mean(tf.square(preds - targets))
grad_w = tape.gradient(loss, w)
print("\nExample 3: gradient of MSE loss w.r.t. weights")
print("  loss   =", loss.numpy())
print("  dL/dw  =", grad_w.numpy())

# Manual gradient update step (gradient descent)
learning_rate = 0.1
w.assign_sub(learning_rate * grad_w)
print("  updated w =", w.numpy())
