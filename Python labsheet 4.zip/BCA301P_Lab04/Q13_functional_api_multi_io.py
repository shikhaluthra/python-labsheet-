"""
Q13: Demonstrate training a model using the Functional API
for multiple inputs and outputs.
Inputs : numeric features (branch A) and a second feature set (branch B)
Outputs: a binary class label and a regression value
"""
import numpy as np
import tensorflow as tf

np.random.seed(11)
tf.random.set_seed(11)

# 1. Synthetic data with two inputs and two targets
N = 1000
X_a = np.random.randn(N, 5).astype("float32")     # input 1
X_b = np.random.randn(N, 3).astype("float32")     # input 2
y_class = (X_a[:, 0] + X_b[:, 0] > 0).astype("float32")          # target 1
y_reg = (2 * X_a[:, 1] - X_b[:, 1]).astype("float32")            # target 2

# 2. Define two separate input branches
input_a = tf.keras.Input(shape=(5,), name="input_a")
input_b = tf.keras.Input(shape=(3,), name="input_b")
branch_a = tf.keras.layers.Dense(16, activation="relu")(input_a)
branch_b = tf.keras.layers.Dense(16, activation="relu")(input_b)

# 3. Merge the branches
merged = tf.keras.layers.concatenate([branch_a, branch_b])
shared = tf.keras.layers.Dense(32, activation="relu")(merged)

# 4. Two output heads
out_class = tf.keras.layers.Dense(1, activation="sigmoid", name="class_out")(shared)
out_reg = tf.keras.layers.Dense(1, name="reg_out")(shared)

model = tf.keras.Model(inputs=[input_a, input_b], outputs=[out_class, out_reg])
model.summary()

# 5. Compile with a loss and weight for each output
model.compile(
    optimizer="adam",
    loss={"class_out": "binary_crossentropy", "reg_out": "mse"},
    loss_weights={"class_out": 1.0, "reg_out": 0.5},
    metrics={"class_out": "accuracy", "reg_out": "mae"}
)

# 6. Train with a list of inputs and a list of targets
model.fit(
    [X_a, X_b], [y_class, y_reg],
    epochs=40, batch_size=32, validation_split=0.2, verbose=0
)

# 7. Evaluate and predict on new data
results = model.evaluate([X_a[:200], X_b[:200]], [y_class[:200], y_reg[:200]], verbose=0)
print("Total loss and per-output metrics:", np.round(results, 4))

new_a = np.array([[1.0, 0.0, 0.0, 0.0, 0.0]], dtype="float32")
new_b = np.array([[1.0, 0.0, 0.0]], dtype="float32")
prob, value = model.predict([new_a, new_b], verbose=0)
print(f"Class probability: {prob[0][0]:.3f}, regression output: {value[0][0]:.3f}")
