"""
Q12: Train a network with dropout layers and explain its effect on overfitting.
Dropout randomly sets a fraction of activations to zero during training,
which discourages the network from memorizing the training data.
We compare a model without dropout against one with dropout.
"""
import numpy as np
import tensorflow as tf

np.random.seed(5)
tf.random.set_seed(5)

# Small noisy dataset with few samples: prone to overfitting
X = np.random.randn(300, 20).astype("float32")
y = (X[:, 0] + 0.5 * X[:, 1] + np.random.randn(300) * 0.8 > 0).astype("float32")
X_tr, X_val = X[:200], X[200:]
y_tr, y_val = y[:200], y[200:]


def build(use_dropout, rate=0.5):
    layers = [tf.keras.layers.Dense(256, activation="relu", input_shape=(20,))]
    if use_dropout:
        layers.append(tf.keras.layers.Dropout(rate))
    layers += [tf.keras.layers.Dense(256, activation="relu")]
    if use_dropout:
        layers.append(tf.keras.layers.Dropout(rate))
    layers.append(tf.keras.layers.Dense(1, activation="sigmoid"))
    m = tf.keras.Sequential(layers)
    m.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    return m


results = {}
for name, use_do in [("No dropout", False), ("With dropout", True)]:
    model = build(use_do)
    h = model.fit(X_tr, y_tr, validation_data=(X_val, y_val),
                  epochs=100, batch_size=16, verbose=0)
    tr_acc = h.history["accuracy"][-1]
    val_acc = h.history["val_accuracy"][-1]
    results[name] = (tr_acc, val_acc)
    print(f"{name:14s} | train acc = {tr_acc:.3f} | val acc = {val_acc:.3f} "
          f"| gap = {tr_acc - val_acc:+.3f}")

print("\nExplanation:")
print("A smaller gap between training and validation accuracy indicates less overfitting.")
print("Dropout forces the network to learn redundant, robust features, so it")
print("usually reduces the gap, at the cost of slightly slower training.")
